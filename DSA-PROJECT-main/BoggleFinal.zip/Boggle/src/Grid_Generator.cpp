#include "Grid_Generator.h"


// the object that handle the text color on console
static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
// vector of colors having different colors in it
static vector<WORD> colors = {FOREGROUND_RED, FOREGROUND_GREEN, FOREGROUND_BLUE, FOREGROUND_RED | FOREGROUND_GREEN,
                        FOREGROUND_RED | FOREGROUND_BLUE, FOREGROUND_GREEN | FOREGROUND_BLUE};

// Constructor
Grid_Generator::Grid_Generator(Grid& grid)
{
    // To bring words for the game
    word_fetcher(grid);
    // To place the word in a grid
    placer(grid);
    // Fill the empty space with random characters
    random_chars(grid);
}

// Destructor
Grid_Generator::~Grid_Generator()
{
    //dtor
}

// To bring words for the game
void Grid_Generator::word_fetcher(Grid& grid)
{
    // The file object that will read from file
    fstream in("Words_Dic.txt");
    // String to store each word one by one
    string s;
    int count;
    // Loop for number of required words
    for(int i = 0; i < 6; i++)
    {
        count = rand() % 10;
        while(count != 0)
        {
            // Read from the file into s string
            getline(in, s);
            count--;
        }
        if(count == 0)
        getline(in, s);
        // Push it in a heap
        heap.add_word(s);
        // Push the word in a string vector
        grid.push_word(s);
        // Clear the string to avoid overlapping
        s.clear();
    }
}

// To place the word in a grid randomly
void Grid_Generator::placer(Grid& grid)
{
    // Possible directions array
    pair<int,int> dir[] = {{1,1}, {-1,1}, {1,-1}, {-1,-1}, {1,0}, {-1,0}, {0,1}, {0,-1}};
    // Place the words in the grid until heap empty as words are in the heap
    while(!heap.isEmpty())
    {
        // Store the word and remove it from the heap
        string word = heap.remove_word();
        // Calculate its length
        int length_word = word.length();
        // Flag to indicate its placement status as it is placed or not
        bool flag = false;
        // Loop will be run until the word is placed in a grid
        while(!flag)
        {
            // Take the random position in a grid
            int start_r = rand() % grid.rows;
            int start_c = rand() % grid.cols;

            // Check all 8 possible directions
            for(int i = 0; i < 8; i++)
            {
                // Calculate its ending coordinate of the word
                int end_r = start_r + (length_word - 1) * dir[i].first;
                int end_c = start_c + (length_word - 1) * dir[i].second;

                // If the ending coordinate is valid and the word can be placed
                if(end_r >= 0 && end_r < grid.rows && end_c >= 0 && end_c < grid.cols && canPlace(grid, word, length_word, start_r, start_c, dir[i].first, dir[i].second))
                {
                    // Loop for placing the word in a grid
                    for(int j = 0; j < length_word; j++)
                    {
                        // Place a character
                        grid.grid[start_r][start_c].first = word[j];
                        // Update row position
                        start_r += dir[i].first;
                        // Update column position
                        start_c += dir[i].second;
                    }
                    // then simply set flag to true that the word is placed successfully
                    flag = true;
                    // break out of the loop
                    break;
                }
            }
        }
    }
}

// To check if the word can be placed
bool Grid_Generator::canPlace(Grid& grid, string& word, int word_length, int r_st, int c_st, int dr, int dc)
{
    // Iterate up to word length
    for(int i = 0; i < word_length; i++)
    {
        // If the cell is not empty and the character needed to place is not its equivalent then simply return false
        if(grid.grid[r_st][c_st].first != '.' && grid.grid[r_st][c_st].first != word[i])
        return false;
        // Update row position
        r_st += dr;
        // Update column position
        c_st += dc;
    }
    return true;
}

// Fill the empty space with random characters
void Grid_Generator::random_chars(Grid& grid)
{
    // loop through rows
    for(int i = 0; i < grid.rows; i++)
    {
        // loop through columns
        for(int j = 0; j < grid.cols; j++)
        {
            // If the grid is empty
            if(grid.grid[i][j].first == '.')
            {
                // Generate the random character
                char ch = (rand() % 26) + 'a';
                // Fill the cell with the random character
                grid.grid[i][j].first = ch;
            }
        }
    }
}
