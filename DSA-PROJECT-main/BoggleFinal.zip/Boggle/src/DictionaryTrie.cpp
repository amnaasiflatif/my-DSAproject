#include "DictionaryTrie.h"

// Constructor
DictionaryTrie::DictionaryTrie()
{
    // Creating the root node
    root = new Node();
}

// Default Constructor
DictionaryTrie::~DictionaryTrie()
{

}

// Insert the word in a trie
void DictionaryTrie::insert(string word)
{
    // Current node pointing to the root
    Node* curr = root;
    // Store the length of the word up to which we traversed the trie
    int size = word.length();
    // Loop to traverse the trie
    for(int i = 0; i < size; i++){
        // If element does not exist
        if(!curr->ifExist(word[i])){
            // Create the new node
            Node* newNode = new Node();
            // Insert the node pointer in the previous node
            curr->put(word[i], newNode);
        }
        // the simply move to the next node
        curr = curr->next(word[i]);
    }
    // At last simply mark the end of the word
    curr->putEnd();
}

// Search the word in a trie
bool DictionaryTrie::search(string word)
{
    // Current pointing to the root
    Node* curr = root;
    // Store the length of the word up to which we traverse
    int length = word.length();
    // Loop to traverse the trie
    for(int i = 0; i < length; i++)
    {
        // First find index of the corresponding character
        int ch = word[i] - 'a';
        // if the character does not exist simply return false
        if(curr->next(ch) == NULL)
        return false;
        // If the character exists then go to the next node
        else
        curr = curr->next(ch);
    }
    // At las we have to check whether the word has ending or not so, return according to it
    return curr->isEnd();
}

// To get the root node
Node* DictionaryTrie::get_root()
{
    // Returning root node
    return root;
}




