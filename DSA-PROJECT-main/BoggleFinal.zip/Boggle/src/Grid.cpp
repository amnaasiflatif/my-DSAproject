#include "Grid.h"

static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
// Array of some colors to select random color from it for the found word
static vector<WORD> colors = {FOREGROUND_RED, FOREGROUND_GREEN, FOREGROUND_BLUE, FOREGROUND_RED | FOREGROUND_GREEN,
                        FOREGROUND_RED | FOREGROUND_BLUE, FOREGROUND_GREEN | FOREGROUND_BLUE};
// Constructor
Grid::Grid(int rows, int cols)
{
    // At initial the counter is zero as no word exists initially
    counter = 0;
    // set the number of rows of a grid
    this->rows = rows;
    // set the number of columns of a grid
    this->cols = cols;
    // resizing the grid according to given rows and columns
    grid.resize(rows, vector<pair<char, WORD>>(cols, {'.', FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE}));
}

// Copy Constructor
Grid::Grid(Grid& other_grid)
{
    // set the number of rows of a grid
    rows = other_grid.rows;
    // set the number of columns of a grid
    cols = other_grid.cols;
    // resizing the grid according to given grid
    grid.resize(rows, vector<pair<char,WORD>>(cols, {'.', FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE}));

    // now traversing each cell of given grid and assign its values to the grid
    // row loop
    for(int i = 0; i < rows; i++)
    {
        // column loop
        for(int j = 0; j < cols; j++)
        {
            // assigning character
             grid[i][j].first = other_grid.grid[i][j].first;
            // assigning color
            grid[i][j].second = other_grid.grid[i][j].second;
        }
    }
    // Copy all the words in the words vector
    words = other_grid.get_words();
    // Copy the count of the word
    counter = other_grid.counter;
}

// Destructor
Grid::~Grid()
{
    //dtor
}

// Display the whole grid
void Grid::print_Grid() const
{
    // Traversing each cell in a grid
    // row loop
    for(int i = 0; i < rows; i++)
    {
        // column loop
        for(int j = 0; j < cols; j++)
        {
            // To display colored character first set the color given in the respective cell
            SetConsoleTextAttribute(hConsole, grid[i][j].second);
            // Now print the cell character
            cout << grid[i][j].first << " ";
        }
        cout << endl;
    }
    // At last selecting white color back; its helps if the last character is colored
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}

// push the string in a vector
void Grid::push_word(string word)
{
    words.push_back(word);
    counter++;
}

// Return the string vector
vector<string> Grid::get_words()
{
    return words;
}

void Grid::print_words()
{
    for(int i = 0; i < words.size(); i++)
    cout << words[i] << " ";
}
