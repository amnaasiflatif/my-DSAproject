#include "AutoSolve.h"

// the object that handle the text color on console
static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
// vector of colors having different colors in it
static vector<WORD> colors = {FOREGROUND_RED, FOREGROUND_GREEN, FOREGROUND_BLUE, FOREGROUND_RED | FOREGROUND_GREEN,
                        FOREGROUND_RED | FOREGROUND_BLUE, FOREGROUND_GREEN | FOREGROUND_BLUE};

// Constructor
AutoSolve::AutoSolve(Grid& other_grid) : GridSolver(other_grid)
{

}

// Destructor
AutoSolve::~AutoSolve()
{
    //dtor
}

// Function to solve the grid
bool AutoSolve::solve()
{
    // Function that displays the word bank
    display_wordBank();
    cout << "================== SOLVE GRID ================" << endl;
    // Build the trie to track the valid word
    build_trie(grid);
    // Valid paths from each cell row wise
    int dr[] = {-1, 1, 0, 0, 1, -1, -1, 1};
    // Valid paths from each cell col wise
    int dc[] = {0, 0, 1, -1, 1, 1, -1, -1};
    vector<vector<bool>> vis(grid.rows, vector<bool>(grid.cols, false));
    // To solve the grid need to traverse grid each cell
    // row loop
    for(int i = 0; i < grid.rows; i++)
    {
        // column loop
        for(int j = 0; j < grid.cols; j++)
        {
            // loop for each direction as multiple words can be start from each cell in any direction
            for(int k = 0; k < 8; k++)
            {
                // Pointer to traverse the trie in word direction
                Node* node = t.root;
                // Position of character in an array
                int ch = grid.grid[i][j].first - 'a';

                // Check if the character is invalid or the character exists
                if(ch < 0|| ch > 25 || node->element[ch] == NULL)
                continue;

                // generate the random color
                WORD color = colors[rand() % 6];

                // If the character is single then this will work for it
                if(node->element[ch]->flag)
                grid.grid[i][j].second = color;

                // if at that position the pointer is not NULL this means character matches
                // So simply call helper function to traverse in the given direction
                if(node->element[ch] != NULL)
                {
                    // call the helper to solver the grid
                    helper_solve(node, color, i, j, dr[k], dc[k], vis);
                }
            }
        }
    }
    // Once the grid is solved its time to print it
    grid.print_Grid();
    cout << "==============================================" << endl;
    // if the grid solved return true else return false
    return grid.counter == 0;
}


// Helper function to solve the grid
bool AutoSolve::helper_solve(Node* node, WORD& color, int r, int c, int dr, int dc, vector<vector<bool>>& visited)
{
    // if one of the conditions gets correct this means that we have reached out of the grid boundary so simply return
    if(r < 0 || c < 0 || r >= grid.rows || c >= grid.cols)
    return false;

    // Position of character in an array
    int ch = grid.grid[r][c].first - 'a';

    // If the position is not in boundaries of array so simply return
    if(ch < 0 || ch >= 26 || node->element[ch] == NULL)
    return false;

    // Point to the next element as it exists (check above)
    node = node->element[ch];

    if(grid.grid[r][c].second == FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE)
    {
        // setting the color of the cell
        grid.grid[r][c].second = color;
    }

    if(node->flag)
    {
         // Mark the cell visited if the word is found to prevent from marking it as white
        visited[r][c] = true;
        // set the flag as false that indicates word has bee searched
        node->set_false();
        // if the word is searched decrement the word count in the grid
        grid.counter--;
        // return true as the word has been searched
        return true;
    }

    // call the recursive function and on backtrack check if the word was found simply return true
    if(helper_solve(node, color, r + dr, c + dc, dr, dc, visited))
    {
        // Mark the cell visited if the word is found to prevent from marking it as white
        visited[r][c] = true;
        // return true as the word found
        return true;
    }
    if(!visited[r][c])
    {
        // if it return false this means word not found so change the color to white at backtrack
        grid.grid[r][c].second = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
    }
    // return false as word was not found
    return false;
}

