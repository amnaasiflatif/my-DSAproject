#include "Node.h"

// Constructor
Node::Node()
{
    // Initially the node has  NULL values
    for(int i = 0; i < 26; i++)
        element[i] = nullptr;
    // Initially the word complete flag is false
    flag = false;
}

// Destructor
Node::~Node()
{
    // Delete the whole array
    delete[] element;
    // Now delete the node
    delete this;
}

// Check if the node exists
bool Node::ifExist(char ch){
    // Return true if it has non null value
    return element[ch - 'a'] != nullptr;
}

// To insert the element in a node
void Node::put(char ch, Node* node){
    // Simply assign the node
    element[ch - 'a'] = node;
}

// Mark end of the word
void Node::putEnd(){
    // make the flag true
    flag = true;
}

// Check if the word is end
bool Node::isEnd(){
    // if the node is true this mean that the word is end
    return flag == true;
}

// To obtain the next node
Node* Node::next(char ch){
    // Return the next node pointing to
    return element[ch - 'a'];
}

// To remove the indication of  end of the word
void Node::set_false()
{
    // make the flag false
    flag = false;
}
