#include "InputGrid.h"

// Constructor
InputGrid::InputGrid(Grid& grid, int numberOfwords)
{
    // Function to ask the user to input the grid
    input_grid(grid);
    // Function that ask the user for words needed to search and store them
    input_words(grid, numberOfwords);
}

// Destructor
InputGrid::~InputGrid()
{
    //dtor
}

// Input grid from the player
void InputGrid::input_grid(Grid& grid)
{
    // Input variable
    char ch;
    cout << "================ ENTER THE GRID ===============" << endl;
    // Loop through rows
    for(int i = 0; i < grid.rows; i++)
    {
        cout << "Enter line " << i + 1 << " : ";
        // Loop through columns
        for(int j = 0; j < grid.cols; j++)
        {
            // Input single character
            cin >> ch;
            // Simply placed it in a grid
            grid.grid[i][j].first = ch;
        }
        // add end of line after each line
        cout << endl;
    }
}

// Input Words needed to search
void InputGrid::input_words(Grid& grid, int numberOfwords)
{
    cout << "================== ENTER WORDS =================" << endl;
    // String to input the words
    string s;
    // Loop to read all the words
    for(int i = 0; i < numberOfwords; i++)
    {
        cout << "Enter string " << i + 1 << " : ";
        // Input each word
        cin >> s;
        // Simply push it in the array of the grid
        grid.push_word(s);
    }
}
