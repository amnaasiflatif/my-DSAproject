#include "UserSolve.h"

static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
static vector<WORD> colors = {FOREGROUND_RED, FOREGROUND_GREEN, FOREGROUND_BLUE, FOREGROUND_RED | FOREGROUND_GREEN,
                        FOREGROUND_RED | FOREGROUND_BLUE, FOREGROUND_GREEN | FOREGROUND_BLUE};

// Constructor
UserSolve::UserSolve(Grid& other_grid) : GridSolver(other_grid)
{
    // Calling the copy constructor of grid class to make copy which is going to be solved
}

// Destructor
UserSolve::~UserSolve()
{
    //dtor
}

// Function to solve the grid using user commands
bool UserSolve::solve()
{
    // First build the trie to search for the words
    build_trie(grid);
    // Variables for user command
    int r_st, r_end, c_st, c_end;
    // The loop to maintain the flow ; solving and user input
    while(1)
    {
        cout << "============= Command Section =============" << endl;
        cout << "Enter the 1st coordinate" << endl;
        // Ask the user for starting row point
        while(1)
        {
            cout << "Start Row : ";
            // Input the starting row point if it is valid then break from the loop
            if(cin >> r_st)
            break;
            // make the cin get ready to take new input
            cin.clear();
            // flush out the invalid characters in the cin
            cin.ignore(1, '\n');
            // Display the invalid command message
            cout << "Invalid Command" << endl;
        }
        // Ask the user for starting col point
        while(1)
        {
            cout << "Start Column : ";
            // Input the starting col point if it is valid then break from the loop
            if(cin >> c_st)
            break;
            // make the cin get ready to take new input
            cin.clear();
            // flush out the invalid characters in the cin
            cin.ignore(1, '\n');
            // Display the invalid command message
            cout << "Invalid Command" << endl;
        }
        // Ask the user for ending row point
        cout << "Enter the 2nd coordinate" << endl;
        while(1)
        {
            cout << "End Row : ";
            // Input the ending row point if it is valid then break from the loop
            if(cin >> r_end)
            break;
            // make the cin get ready to take new input
            cin.clear();
            // flush out the invalid characters in the cin
            cin.ignore(1, '\n');
            // Display the invalid command message
            cout << "Invalid Command" << endl;
        }
        // Ask the user for ending col point
        while(1)
        {
            cout << "End Column : ";
            // Input the ending col point if it is valid then break from the loop
             if(cin >> c_end)
            break;
            // make the cin get ready to take new input
            cin.clear();
            // flush out the invalid characters in the cin
            cin.ignore(1, '\n');
            // Display the invalid command message
            cout << "Invalid Command" << endl;
        }
        // Call the input coordinates function that takes coordinates and check if the word exists
        if(input_coordiantes(r_st, c_st, r_end, c_end))
        {
            // If the the counter is 0 then this means all words are found
            if(grid.counter == 0)
            {
                // Display the message for all the words are found
                cout << "All words are found";
                // Print the grid
                grid.print_Grid();
                // Break from the loop
                break;
            }
        }
        // If the word is not found simply display Word not found message
        else
        cout << "Word not found" << endl;
        // The function that displays the word bank
        display_wordBank();
        cout << "==================== Grid ====================" << endl;
        // Print the grid
        grid.print_Grid();
        cout << "==============================================" << endl;
        // Variable to check the user command
        char command;
        while(1)
        {
            cout << "Enter y/Y to proceed the game \n Enter n/N to auto solve it : ";
            // Ask for the command
            cin >> command;
            // If the user inputs y/Y simply exist
            if(command == 'y' || command == 'Y' )
            break;
            // If the user input n/N return false with which it will be solved by the auto solver
            else if(command == 'n' || command == 'N')
            return false;
            // Display invalid command message
            else
            cout << "Invalid Command" << endl;
        }
    }
    // Return true if the grid is solved
    return true;
}
// Takes coordinates of the word needed to search in a grid
bool UserSolve::input_coordiantes(int r_st, int c_st, int r_end, int c_end)
{
    // Check length of the word
    int length = max(abs(r_st - r_end), abs(c_st - c_end)) + 1;
    int dr, dc;
    // if the length is 0 so make the dr and dc equal to zero
    if(length == 1)
    {
        dr = 0;
        dc = 0;
    }
    else
    {
        // Compute the change in row
        dr = (r_end - r_st) / (length - 1);
        // Compute the change in column
        dc = (c_end - c_st) / (length - 1);
        // Generate the random color
    }
    // select the color randomly
    WORD color = colors[rand() % 6];
    // Take the root of the trie
    Node* node = t.root;
    // call the helper function to check and update if the input word exists
    return helper_solve(node, color, length, r_st, c_st, dr, dc);
}

// To check if the word exists and if it exists then mark
bool UserSolve::helper_solve(Node* node, WORD& color, int length, int r, int c, int dr, int dc)
{
    // if the coordinate position is out of grid or the length is less then zero then return false
    if(node == NULL || length < 0 || r < 0 || c < 0 || r >= grid.rows || c >= grid.cols)
    return false;

    int ch = grid.grid[r][c].first - 'a';

    if(ch < 0 || ch > 25 || node->element[ch] == NULL)
    return false;

    // color the character
    grid.grid[r][c].second = color;

    node = node->element[ch];

    // If reached to the end of the character then simply return true as word is found
    if(length == 1 && node->isEnd())
    {
        // If the word is found simply make flag false with which word is now removed
        node->set_false();
        // Decrement the counter of the remaining words
        grid.counter--;
        // return true that the word is found
        return true;
    }

    // If the word found return true
    if(helper_solve(node, color, length - 1, r + dr, c + dc, dr, dc))
    return true;

    // If the word does not exist at backtrack set color back to white
    grid.grid[r][c].second = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
    // return false then
    return false;
}

