#include "Maxheap.h"

// Constructor
Maxheap::Maxheap(int capacity)
{
    // Resize the heap array
    max_heap.resize(capacity);
    // Initially the heap is empty so size is 0
    heap_size = 0;
}

// Destructor
Maxheap::~Maxheap()
{
    /*for(int i = 1; i <= heap_size; i++)
    delete max_heap[i];

    delete[] max_heap;*/
    // Set teh heap size to 0
    heap_size = 0;
}

// Add the word in a heap
void Maxheap::add_word(string word)
{
    // Calculate the word length
    int word_size = word.length();
    // Search if the node exists that have the words of same length
    heapNode* node = search_node(word_size);
    // If the node is found
    if(node != NULL)
    {
        // Add the word in that node
        node->words_array.push_back(word);
        // Update the size of the array in the heap
        node->size++;
    }
    // if node is not found make a new node
    else
    insert_node(word);
}

// Insert the new node in a heap
void Maxheap::insert_node(string word)
{
    // Update the heap size
    heap_size++;
    // If heap is full then resize it to its double length
    if(heap_size >= max_heap.size())
    max_heap.resize(heap_size * 2);

    // Create the new node
    heapNode* newNode = new heapNode;
    // Set the length value
    newNode->length = word.size();
    // Set the array size
    newNode->size = 1;
    // Pus the word in the new node
    newNode->words_array.push_back(word);

    // Now add the new node at the end of the heap
    max_heap[heap_size] = newNode;
    // Call percolate up to validate the max heap property
    percolate_up();
}

// Remove the word from the heap
string Maxheap::remove_word()
{
    // check the size of the array in a node
    int size = max_heap[1]->size;
    // Save the word which will be deleted from the array
    string word = max_heap[1]->words_array[size - 1];
    // pop out the element
    max_heap[1]->words_array.pop_back();
    // Update the size of the array in the node
    max_heap[1]->size--;

    // If the array in a node is empty then simply remove it from the max heap
    if(max_heap[1]->size == 0)
    removeMax();

    // Return the word
    return word;
}

// To search the node in a heap
heapNode* Maxheap::search_node(int length)
{
    // If the heap is empty simply return NULL
    if(isEmpty())
    return NULL;

    // Current initially pointing to the root
    heapNode* curr = max_heap[1];
    // To traverse the whole
    for(int i = 1; i <= heap_size; i++)
    {
        // If the node is found return it
        if(curr->length == length)
        return curr;
    }
    // Return NULL if the node is not found
    return NULL;
}

// Remove max element from the heap
void Maxheap::removeMax()
{
    // If the heap is empty return
    if(isEmpty())
    return;
    // Copy the last node into the first node and delete the last node
    max_heap[1] = max_heap[heap_size--];
    // Call percolate down to validate max heap properties
    percolate_down();
}

// Validate the max heap by moving up
void Maxheap::percolate_up()
{
    // Initially the hole s the last node
    int hole = heap_size;
    // The node that needed to be place
    heapNode* node = max_heap[hole];
    // The temp to check for the length
    int temp = node->length;
    // Iterate until the correct hole position is found or reaches to the root
    for(; hole > 1 && temp > max_heap[hole/2]->length; hole = hole/2)
    max_heap[hole] = max_heap[hole/2];

    // Now place the node at hole
    max_heap[hole] = node;
}

// Validate the max heap by moving down
void Maxheap::percolate_down()
{
    // child node
    int child;
    // Initially hole at node 1
    int hole = 1;
    // The node that needed to be place
    heapNode* node = max_heap[1];
    // The temp to check for the length
    int temp = node->length;
    // Iterate until the hole is found or reached to the last node
    for(; hole * 2 <= heap_size; hole = child)
    {
        // Calculate the child position
        child = hole * 2;
        // Check if the second child exists and the second child is greater
        if(child + 1 <= heap_size && max_heap[child + 1]->length > max_heap[child]->length)
        {
            // Update the child as we need the child will greater value
            child++;
        }
        // If the child is greater then the parent copy move the node up to hole
        if(temp < max_heap[child]->length)
        max_heap[hole] = max_heap[child];
        // The hole is found so break the loop
        else
        break;
    }
    // Place the node in a hole
    max_heap[hole] = node;
}

// Check if the heap is empty
bool Maxheap::isEmpty()
{
    // If the heap size is zero so the heap is empty
    return heap_size == 0;
}

