#include "GridSolver.h"

// Constructor
GridSolver::GridSolver(Grid& other_grid)
{
    grid = Grid(other_grid);
}

// Destructor
GridSolver::~GridSolver()
{
    //dtor
}

/*
GridSolver::solve()
{
}*/

// To build trie from words
void GridSolver::build_trie(Grid& other_grid)
{
    // Get the array of words
    vector<string> words = other_grid.get_words();
    // Calculate the size of the array
    int size = words.size();
    // Loop through the array
    for(int i = 0; i < size ; i++)
    {
        // Insert the word in a trie
        t.insert(words[i]);
    }
}

// The function that displays the word bank
void GridSolver::display_wordBank()
{
    // Clear the console first
    system("cls");
    cout << "================= Word Bank ==================";
    cout << endl;
    // Print all the words needed search in a grid
    for(string s : grid.get_words())
    cout << s << " ";
    cout << endl;
}

